// constants.js
export const MAX_USERS_PER_ROOM = 2;